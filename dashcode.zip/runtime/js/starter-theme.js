(function () {
    'use strict';

    const modalSelector = '.modal.show, .modal.d-block';

    const closeModal = (modal) => {
        if (! modal) return;
        modal.classList.remove('show', 'd-block');
        modal.setAttribute('aria-hidden', 'true');
        if (! document.querySelector(modalSelector)) document.body.classList.remove('starter-modal-open');
    };

    const openModal = (modal) => {
        if (! modal) return;
        modal.classList.add('show', 'd-block');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('starter-modal-open');
        requestAnimationFrame(() => modal.querySelector('input:not([type="hidden"]),select,textarea,button')?.focus());
    };

    const closeNavigation = () => document.body.classList.remove('starter-sidebar-open');

    const bind = () => {
        if (window.__starterDashcodeBound) return;

        document.addEventListener('click', (event) => {
            const sidebarOpen = event.target.closest('[data-starter-sidebar-open]');
            if (sidebarOpen) {
                event.preventDefault();
                document.body.classList.add('starter-sidebar-open');
                return;
            }

            const sidebarClose = event.target.closest('[data-starter-sidebar-close]');
            if (sidebarClose) {
                event.preventDefault();
                closeNavigation();
                return;
            }

            const modalOpen = event.target.closest('[data-starter-modal-open]');
            if (modalOpen) {
                event.preventDefault();
                openModal(document.querySelector(modalOpen.dataset.starterModalOpen));
                return;
            }

            const modalClose = event.target.closest('[data-starter-modal-close]');
            if (modalClose) {
                event.preventDefault();
                closeModal(modalClose.closest('.modal'));
                return;
            }

            const modal = event.target.closest('.modal');
            if (modal && event.target === modal && ! modal.hasAttribute('wire:click.self')) closeModal(modal);
        });

        document.addEventListener('keydown', (event) => {
            if (event.key !== 'Escape') return;
            const modal = document.querySelector(modalSelector);
            if (modal) {
                closeModal(modal);
                return;
            }
            closeNavigation();
        });

        window.__starterDashcodeBound = true;
    };

    window.StarterThemeAdapter = {
        prepare() {
            bind();
            if (window.innerWidth >= 1280) closeNavigation();
        },
        dispose() {
            closeNavigation();
            document.querySelectorAll(modalSelector).forEach(closeModal);
        },
        closeNavigation,
        openAppMenu(menu) { menu?.classList.add('show'); },
        closeAppMenu(menu) { menu?.classList.remove('show'); },
        openModal,
        closeModal,
    };
})();

