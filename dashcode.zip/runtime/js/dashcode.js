(function () {
    'use strict';

    const modalSelector = '.modal.show';
    const focusableSelector = 'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
    const previousFocus = new WeakMap();

    const closeModal = (modal) => {
        if (! modal) return;
        modal.classList.remove('show');
        modal.setAttribute('aria-modal', 'false');
        modal.setAttribute('aria-hidden', 'true');
        if (! document.querySelector(modalSelector)) document.body.classList.remove('starter-modal-open');
        previousFocus.get(modal)?.focus?.();
        previousFocus.delete(modal);
    };

    const openModal = (modal) => {
        if (! modal) return;
        previousFocus.set(modal, document.activeElement);
        modal.classList.add('show');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('starter-modal-open');
        requestAnimationFrame(() => modal.querySelector(focusableSelector)?.focus());
    };

    const closeNavigation = () => document.body.classList.remove('starter-sidebar-open');

    const bind = () => {
        if (window.__starterDashcodeBound) return;

        document.addEventListener('click', (event) => {
            const sidebarOpen = event.target.closest('[data-starter-sidebar-open]');
            if (sidebarOpen) {
                event.preventDefault();
                document.body.classList.add('starter-sidebar-open');
                return;
            }

            const sidebarClose = event.target.closest('[data-starter-sidebar-close]');
            if (sidebarClose) {
                event.preventDefault();
                closeNavigation();
                return;
            }

            const modalOpen = event.target.closest('[data-starter-modal-open]');
            if (modalOpen) {
                event.preventDefault();
                openModal(document.querySelector(modalOpen.dataset.starterModalOpen));
                return;
            }

            const modalClose = event.target.closest('[data-starter-modal-close]');
            if (modalClose) {
                event.preventDefault();
                closeModal(modalClose.closest('.modal'));
                return;
            }

            const modal = event.target.closest('.modal');
            if (modal && event.target === modal && ! modal.hasAttribute('wire:click.self')) closeModal(modal);
        });

        document.addEventListener('keydown', (event) => {
            const modal = document.querySelector(modalSelector);
            if (event.key === 'Escape' && modal) {
                closeModal(modal);
                return;
            }

            if (event.key === 'Escape') {
                closeNavigation();
                return;
            }

            if (event.key !== 'Tab' || ! modal) return;
            const focusable = [...modal.querySelectorAll(focusableSelector)].filter((element) => ! element.hidden && element.offsetParent !== null);
            if (! focusable.length) {
                event.preventDefault();
                modal.focus();
                return;
            }

            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (! event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });

        window.__starterDashcodeBound = true;
    };

    window.StarterThemeAdapter = {
        prepare() {
            bind();
            if (window.innerWidth >= 1280) closeNavigation();
            const modal = document.querySelector(modalSelector);
            if (modal) {
                modal.setAttribute('aria-modal', 'true');
                modal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('starter-modal-open');
            }
        },
        dispose() {
            closeNavigation();
            document.querySelectorAll(modalSelector).forEach(closeModal);
        },
        closeNavigation,
        openAppMenu(menu) { menu?.classList.add('show'); },
        closeAppMenu(menu) { menu?.classList.remove('show'); },
        openModal,
        closeModal,
    };
})();
